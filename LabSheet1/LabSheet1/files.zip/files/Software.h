#pragma once
#ifndef Software_h
#define Software_h
#include <string>
#include "Products.h"

class Software : public Product
{
public:
	//double getGrossPrice();
	Software(double d);
	//Software();

private:


	

};


#endif // !Software.h


#include "Software.h"
using namespace std;



Software::Software(double d)
	:Product(d)
{
	
}

